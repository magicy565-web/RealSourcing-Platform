import React, { useState } from "react";
import {
  Building2, MapPin, Star, Package, Clock, CheckCircle2,
  Handshake, FileText, Video, ChevronDown, Sparkles, TrendingUp,
  AlertCircle, ArrowRight,
} from "lucide-react";

interface QuoteCard {
  quoteId: string;
  factoryId?: number;
  factoryName: string;
  factoryScore: number;
  isVerified: boolean;
  productName: string;
  productCategory?: string;
  unitPrice?: number | null;
  currency?: string;
  moq?: number;
  leadTimeDays?: number;
  matchScore: number;
  matchReasons?: string[];
  certifications?: string[];
  location?: string;
}

type FlowStep = "idle" | "inquiry_sent" | "rfq_sent" | "meeting_booked";

interface QuoteCardRedesignedProps {
  quote: QuoteCard;
  onAction?: (action: "inquiry" | "rfq" | "meeting") => void;
}

export default function QuoteCardRedesigned({ quote, onAction }: QuoteCardRedesignedProps) {
  const [flowStep, setFlowStep] = useState<FlowStep>("idle");
  const [isExpanded, setIsExpanded] = useState(false);
  const [hovered, setHovered] = useState(false);

  const handleInquiry = () => {
    setFlowStep("inquiry_sent");
    onAction?.("inquiry");
  };

  const handleRFQ = () => {
    setFlowStep("rfq_sent");
    onAction?.("rfq");
  };

  const handleMeeting = () => {
    setFlowStep("meeting_booked");
    onAction?.("meeting");
  };

  // 流程步骤配置
  const flowSteps = [
    {
      id: "inquiry",
      label: "发送询盘",
      description: "建立初步联系",
      icon: <Handshake size={16} />,
      color: "#10b981",
      isCompleted: flowStep !== "idle",
      isActive: flowStep === "idle",
      action: handleInquiry,
    },
    {
      id: "rfq",
      label: "发送 RFQ",
      description: "正式报价请求",
      icon: <FileText size={16} />,
      color: "#0ea5e9",
      isCompleted: flowStep === "rfq_sent" || flowStep === "meeting_booked",
      isActive: flowStep === "inquiry_sent",
      action: handleRFQ,
    },
    {
      id: "meeting",
      label: "预约会议",
      description: "视频确认细节",
      icon: <Video size={16} />,
      color: "#7c3aed",
      isCompleted: flowStep === "meeting_booked",
      isActive: flowStep === "rfq_sent",
      action: handleMeeting,
    },
  ];

  // 计算匹配度颜色
  const getMatchColor = (score: number) => {
    if (score >= 90) return "#10b981"; // 绿色
    if (score >= 75) return "#f59e0b"; // 橙色
    return "#ef4444"; // 红色
  };

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: hovered
          ? "linear-gradient(135deg, rgba(124,58,237,0.15) 0%, rgba(99,102,241,0.08) 100%)"
          : "rgba(124,58,237,0.08)",
        border: `1px solid ${hovered ? "rgba(124,58,237,0.4)" : "rgba(124,58,237,0.2)"}`,
        borderRadius: 16,
        overflow: "hidden",
        transition: "all 0.3s ease",
        marginBottom: 12,
      }}
    >
      {/* ─── Header Section ─────────────────────────────────────────────────── */}
      <div style={{ padding: "18px 20px" }}>
        {/* Factory Info + Match Score */}
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 14 }}>
          <div style={{ display: "flex", alignItems: "flex-start", gap: 12, flex: 1 }}>
            {/* Factory Avatar */}
            <div
              style={{
                width: 44,
                height: 44,
                borderRadius: 10,
                background: "linear-gradient(135deg, rgba(124,58,237,0.3), rgba(99,102,241,0.2))",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexShrink: 0,
              }}
            >
              <Building2 size={20} color="#a78bfa" />
            </div>

            {/* Factory Details */}
            <div style={{ flex: 1 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                <h3 style={{ color: "#e2e8f0", fontWeight: 700, fontSize: 15, margin: 0 }}>
                  {quote.factoryName}
                </h3>
                {quote.isVerified && (
                  <span
                    style={{
                      background: "rgba(16,185,129,0.15)",
                      color: "#34d399",
                      fontSize: 10,
                      fontWeight: 700,
                      padding: "2px 8px",
                      borderRadius: 5,
                      display: "flex",
                      alignItems: "center",
                      gap: 3,
                    }}
                  >
                    <CheckCircle2 size={10} />
                    已验证
                  </span>
                )}
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 12, fontSize: 12, color: "#94a3b8" }}>
                <span style={{ display: "flex", alignItems: "center", gap: 3 }}>
                  <MapPin size={12} />
                  {quote.location || "中国"}
                </span>
                <span style={{ display: "flex", alignItems: "center", gap: 3 }}>
                  <Star size={12} color="#fbbf24" />
                  {quote.factoryScore.toFixed(1)} 分
                </span>
              </div>
            </div>
          </div>

          {/* Match Score Badge */}
          <div
            style={{
              textAlign: "center",
              padding: "8px 12px",
              background: `${getMatchColor(quote.matchScore)}15`,
              border: `1px solid ${getMatchColor(quote.matchScore)}40`,
              borderRadius: 10,
              flexShrink: 0,
            }}
          >
            <div style={{ color: getMatchColor(quote.matchScore), fontWeight: 800, fontSize: 20 }}>
              {quote.matchScore}%
            </div>
            <div style={{ color: "#64748b", fontSize: 10, fontWeight: 600 }}>匹配度</div>
          </div>
        </div>

        {/* Match Reasons */}
        {quote.matchReasons && quote.matchReasons.length > 0 && (
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 12 }}>
            {quote.matchReasons.slice(0, 3).map((reason, i) => (
              <span
                key={i}
                style={{
                  background: "rgba(99,102,241,0.12)",
                  color: "#a5b4fc",
                  fontSize: 11,
                  padding: "3px 8px",
                  borderRadius: 6,
                  display: "flex",
                  alignItems: "center",
                  gap: 4,
                }}
              >
                <Sparkles size={10} />
                {reason}
              </span>
            ))}
          </div>
        )}

        {/* Key Specs */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(100px, 1fr))",
            gap: 12,
            marginBottom: 14,
            padding: "12px",
            background: "rgba(15,23,42,0.5)",
            borderRadius: 10,
          }}
        >
          {quote.unitPrice != null && (
            <div>
              <div style={{ color: "#64748b", fontSize: 10, fontWeight: 600, marginBottom: 4 }}>单价</div>
              <div style={{ color: "#f1f5f9", fontWeight: 700, fontSize: 14 }}>
                ${quote.unitPrice.toFixed(2)}
              </div>
            </div>
          )}
          {quote.moq != null && (
            <div>
              <div style={{ color: "#64748b", fontSize: 10, fontWeight: 600, marginBottom: 4 }}>MOQ</div>
              <div style={{ color: "#f1f5f9", fontWeight: 600, fontSize: 13, display: "flex", alignItems: "center", gap: 4 }}>
                <Package size={12} />
                {quote.moq.toLocaleString()}
              </div>
            </div>
          )}
          {quote.leadTimeDays != null && (
            <div>
              <div style={{ color: "#64748b", fontSize: 10, fontWeight: 600, marginBottom: 4 }}>交期</div>
              <div style={{ color: "#f1f5f9", fontWeight: 600, fontSize: 13, display: "flex", alignItems: "center", gap: 4 }}>
                <Clock size={12} />
                {quote.leadTimeDays}天
              </div>
            </div>
          )}
        </div>

        {/* Certifications */}
        {quote.certifications && quote.certifications.length > 0 && (
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 14 }}>
            {quote.certifications.map((cert, i) => (
              <span
                key={i}
                style={{
                  background: "rgba(245,158,11,0.1)",
                  color: "#fbbf24",
                  fontSize: 10,
                  fontWeight: 700,
                  padding: "2px 8px",
                  borderRadius: 6,
                  border: "1px solid rgba(245,158,11,0.2)",
                }}
              >
                {cert}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* ─── Flow Section ──────────────────────────────────────────────────── */}
      <div
        style={{
          borderTop: "1px solid rgba(124,58,237,0.15)",
          padding: "14px 20px",
          background: "rgba(8,8,20,0.4)",
        }}
      >
        {/* Flow Steps */}
        <div style={{ marginBottom: 12 }}>
          {flowSteps.map((step, idx) => (
            <div key={step.id}>
              {/* Step Item */}
              <div
                onClick={step.isActive ? step.action : undefined}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                  padding: "10px 12px",
                  background:
                    step.isCompleted || step.isActive
                      ? `${step.color}12`
                      : "rgba(255,255,255,0.02)",
                  border: `1px solid ${
                    step.isCompleted || step.isActive
                      ? `${step.color}40`
                      : "rgba(255,255,255,0.08)"
                  }`,
                  borderRadius: 10,
                  cursor: step.isActive ? "pointer" : "default",
                  transition: "all 0.2s",
                  marginBottom: idx < flowSteps.length - 1 ? 8 : 0,
                  opacity: step.isActive ? 1 : step.isCompleted ? 0.8 : 0.6,
                }}
              >
                {/* Step Icon */}
                <div
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: 8,
                    background: step.isCompleted ? `${step.color}20` : "rgba(255,255,255,0.05)",
                    border: `1px solid ${step.isCompleted ? `${step.color}60` : "rgba(255,255,255,0.1)"}`,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: step.isCompleted ? step.color : "#64748b",
                    flexShrink: 0,
                  }}
                >
                  {step.isCompleted ? <CheckCircle2 size={16} /> : step.icon}
                </div>

                {/* Step Info */}
                <div style={{ flex: 1 }}>
                  <div
                    style={{
                      color: step.isCompleted ? step.color : "#e2e8f0",
                      fontWeight: 700,
                      fontSize: 13,
                    }}
                  >
                    {step.label}
                  </div>
                  <div style={{ color: "#64748b", fontSize: 11 }}>{step.description}</div>
                </div>

                {/* Action Arrow */}
                {step.isActive && (
                  <ArrowRight
                    size={16}
                    color={step.color}
                    style={{ flexShrink: 0, animation: "pulse 1.5s infinite" }}
                  />
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Status Message */}
        {flowStep !== "idle" && (
          <div
            style={{
              padding: "10px 12px",
              background: `${flowSteps[flowSteps.length - 1].color}12`,
              border: `1px solid ${flowSteps[flowSteps.length - 1].color}40`,
              borderRadius: 10,
              display: "flex",
              alignItems: "center",
              gap: 8,
              color: flowSteps[flowSteps.length - 1].color,
              fontSize: 12,
              fontWeight: 600,
            }}
          >
            <CheckCircle2 size={14} />
            {flowStep === "inquiry_sent" && "询盘已发送！工厂将在 24 小时内回复"}
            {flowStep === "rfq_sent" && "RFQ 已发送！等待工厂的正式报价"}
            {flowStep === "meeting_booked" && "会议已预约！工厂将在 24 小时内确认时间"}
          </div>
        )}
      </div>

      {/* CSS Animation */}
      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
      `}</style>
    </div>
  );
}
