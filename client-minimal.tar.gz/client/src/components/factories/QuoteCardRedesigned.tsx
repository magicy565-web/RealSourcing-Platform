import React, { useState } from "react";
import {
  Building2, MapPin, Star, CheckCircle2,
  Handshake, FileText, Video, ArrowRight
} from "lucide-react";

interface QuoteCard {
  quoteId: string;
  factoryName: string;
  factoryScore: number;
  isVerified: boolean;
  unitPrice?: number | null;
  moq?: number;
  leadTimeDays?: number;
  matchScore: number;
  location?: string;
}

type FlowStep = "idle" | "inquiry_sent" | "rfq_sent" | "meeting_booked";

interface QuoteCardRedesignedProps {
  quote: QuoteCard;
  onAction?: (action: "inquiry" | "rfq" | "meeting") => void;
}

export default function QuoteCardRedesigned({ quote, onAction }: QuoteCardRedesignedProps) {
  const [flowStep, setFlowStep] = useState<FlowStep>("idle");

  const handleAction = () => {
    if (flowStep === "idle") {
      setFlowStep("inquiry_sent");
      onAction?.("inquiry");
    } else if (flowStep === "inquiry_sent") {
      setFlowStep("rfq_sent");
      onAction?.("rfq");
    } else if (flowStep === "rfq_sent") {
      setFlowStep("meeting_booked");
      onAction?.("meeting");
    }
  };

  const getActionButton = () => {
    switch (flowStep) {
      case "idle":
        return { label: "发送询盘", icon: <Handshake size={14} />, color: "#10b981" };
      case "inquiry_sent":
        return { label: "发送正式 RFQ", icon: <FileText size={14} />, color: "#0ea5e9" };
      case "rfq_sent":
        return { label: "预约视频会议", icon: <Video size={14} />, color: "#7c3aed" };
      case "meeting_booked":
        return null;
    }
  };

  const action = getActionButton();

  return (
    <div style={{
      background: "rgba(255, 255, 255, 0.03)",
      border: "1px solid rgba(255, 255, 255, 0.08)",
      borderRadius: 12,
      padding: "16px",
      marginBottom: 12,
      transition: "all 0.2s ease"
    }}>
      {/* Top: Basic Info */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <div style={{ width: 32, height: 32, borderRadius: 6, background: "rgba(124, 58, 237, 0.15)", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Building2 size={16} color="#a78bfa" />
          </div>
          <div>
            <div style={{ color: "#f1f5f9", fontWeight: 600, fontSize: 14, display: "flex", alignItems: "center", gap: 6 }}>
              {quote.factoryName}
              {quote.isVerified && <CheckCircle2 size={12} color="#10b981" />}
            </div>
            <div style={{ color: "#64748b", fontSize: 11, marginTop: 2 }}>
              {quote.location || "中国"} · {quote.factoryScore.toFixed(1)} 评分
            </div>
          </div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ color: "#a78bfa", fontWeight: 700, fontSize: 18 }}>{quote.matchScore}%</div>
          <div style={{ color: "#475569", fontSize: 9, fontWeight: 600, textTransform: "uppercase" }}>Match</div>
        </div>
      </div>

      {/* Middle: Key Specs (Minimalist Row) */}
      <div style={{ display: "flex", gap: 20, marginBottom: 16, padding: "8px 0", borderTop: "1px solid rgba(255,255,255,0.03)" }}>
        {quote.unitPrice && (
          <div>
            <div style={{ color: "#475569", fontSize: 9, marginBottom: 2 }}>PRICE</div>
            <div style={{ color: "#cbd5e1", fontSize: 13, fontWeight: 600 }}>${quote.unitPrice.toFixed(2)}</div>
          </div>
        )}
        {quote.moq && (
          <div>
            <div style={{ color: "#475569", fontSize: 9, marginBottom: 2 }}>MOQ</div>
            <div style={{ color: "#cbd5e1", fontSize: 13, fontWeight: 600 }}>{quote.moq}</div>
          </div>
        )}
        {quote.leadTimeDays && (
          <div>
            <div style={{ color: "#475569", fontSize: 9, marginBottom: 2 }}>LEAD TIME</div>
            <div style={{ color: "#cbd5e1", fontSize: 13, fontWeight: 600 }}>{quote.leadTimeDays}d</div>
          </div>
        )}
      </div>

      {/* Bottom: Single Action Button */}
      {action ? (
        <button
          onClick={handleAction}
          style={{
            width: "100%",
            padding: "10px",
            background: `${action.color}15`,
            border: `1px solid ${action.color}30`,
            borderRadius: 8,
            color: action.color,
            fontSize: 13,
            fontWeight: 600,
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            transition: "all 0.2s"
          }}
          onMouseOver={(e) => e.currentTarget.style.background = `${action.color}25`}
          onMouseOut={(e) => e.currentTarget.style.background = `${action.color}15`}
        >
          {action.icon}
          {action.label}
          <ArrowRight size={14} />
        </button>
      ) : (
        <div style={{
          width: "100%",
          padding: "10px",
          background: "rgba(16, 185, 129, 0.05)",
          border: "1px solid rgba(16, 185, 129, 0.2)",
          borderRadius: 8,
          color: "#10b981",
          fontSize: 12,
          fontWeight: 600,
          textAlign: "center",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: 6
        }}>
          <CheckCircle2 size={14} />
          流程已完成，等待工厂确认
        </div>
      )}
    </div>
  );
}
